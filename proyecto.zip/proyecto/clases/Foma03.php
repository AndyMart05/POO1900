<?php


/**
 *
 */
class Foma03 extends Asignatura
{

   
    public function setAsignaturaI($Asignatura){
        $this->$Asignatura=$Asignatura;
    }
    
    publci function getAsignatura(){
        $this->Asignatura;
    }
    
    public function Guardar():void
    {
        // TODO: implement here
    }

}
