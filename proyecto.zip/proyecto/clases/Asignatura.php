<?php


class Asignatura{
    private $Facultad;
    private $Asignatura;
    private $Seccion;

  
    public function __construct($Facultad, $Asignatura, $Seccion){
        $this->$Facultad=$Facultad;
        $this->$Asignatura=$Asignatura;
        $this->$Seccion=$Seccion;

    }

    public function setFacultad($Facultad){
        $this->$Facultad=$Facultad;
    }

    public function getFacultad(){
        $this->Facultad;
    }

    public function setAsignatura($Asignatura){
        $this->$Asignatura=$Asignatura;
    }

    public function getAsignatura(){
        $this->Asignatura;
    }

    public function setSeccion($Seccion){
        $this->$Seccion=$Asignatura;
    }

    public function getSeccion(){
        $this->Seccion;

    }
   

   
    public function Adicionar():void
    {
     
    }

 
    public function Verificar():void
    {
       
    }

    
    public function Cancelar():void
    {
      
    }

}
