<?php


class Persona{

    private $Nombre;
    private $ID;
    
    public function __construct($Nombre, $ID){
        $this->Nombre=$Nombre;
        $this->ID=$ID;

    }

    public function setNombre($Nombre){
        $this->$Nombre=$Nombre;

    } 
    public function getNombre(){
        $this->Nombre;
    }
 
    public function setID($ID){
        $this->$ID=$ID;
    }

    publci function getID(){
        $this->ID;
    }
    public function Verificar():void
    {
        // TODO: implement here
    }
}
