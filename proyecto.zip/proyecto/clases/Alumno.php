<?php


class Alumno extends Persona{

  
    public $Asignatura;
    public $Cuenta;
    public $Clave;

    public function __construct($Asignatura, $Cuenta, $Clave){
        $this->Asignatura=$Asignatura;
        $this->Clave=$Clave;
        $this->Cuenta=$Cuenta;
    }



    public function setAsignatura($Asignatura){
        $this->$Asignatura=$Asignatura;
    }
    public function getAsignatura(){
        $this->Asignatura;
    }

    public function setCuenta($Cuenta){
        $this->$Cuenta=$Cuenta;
    }

    public function getCuenta(){
        $this->Cuenta;
    }

    public function setClave($Clave){
        $this->$Clave=$Clave;
    }

    public function getClave(){
        $this->Clave;
    }


  
    /*public function Guardar(){
     //   $sql= 
        }
        // TODO: implement here
    }*/

}
