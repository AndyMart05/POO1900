<?php


/**
 *
 */
class Profesor extends Persona
{

    private $Empleado;
    private $Clave;

    public  function setEmpleado($Empleado){
        $this->$Empleado=$Empleado;
    }
    public function getEmpleado(){
        $this->Empleado;
    }

    public function setClave($Clave){
        $this->$Clave=$Clave;
    }
    public function getClave(){
        $this->Clave;
    }

    
    public function Verificar():void
    {
        // TODO: implement here
    }

}
