<?php 

ini_set('display_startup_errors',1);
  error_reporting(E_ALL);

  include ('../conexion.php');  
  $conex = new Conexion();
	$conexion = $conex->conect();
	// $usuario = $_POST['usuario'];
	// $contrasenia = $_POST['contrasenia'];
	$idcarera= $_GET['id_carrera'];
	$sql='SELECT id_asignatura, id_seccion, id_docente, id_aula, id_carrera, codigo_clase, 
	nombre_clase, dias_clase, hora_inicio, hora_fin, cantida_uv
			FROM matricula.tbl_asignaturas where id_carrera= $1 ';
			  
	$consulta = pg_query_params($conexion, $sql, array($idcarera));
	$filas = pg_num_rows($consulta);
	$datos=pg_fetch_array($consulta);
	$conex->cerrarConexion($conexion);

// var_dump($datos);

?>

<html>
	<head>
		<title>Adicionar Asignatura</title>
		<style type="text/css">
		
			*  { 
			padding:0px;
			margin:0px;
			
			}
			
			#header{
				margin:auto;
				width:1000px;
				font-family:Arial,Helvetica,sans-serif;
			}
			
			ul, ol{
				list-style:none;
			}
			
			.nav li a{
				background-color:#262B78;
				color:#fff;
				text-decoration:none;
				padding:10px 15px;
				display:block;
			}
			
			.nav li a:hover {
				background-color:#5e8691;
			}
			.nav > li {
				float:left;
			}
			.nav li ul {
				display:none;
				position:absolute;
				min-width:140px;
			}
			
			.nav li:hover > ul {
				display:block;
			}
			
			.nav li ul li {
				position:relative;
			}
			
			.nav li ul li ul {
				right: -205px;
				top:0px;
				
			}
		</style>
	</head>

    <body>
    	<header>
    		<div>
    			<img src="superior.jpg" width="1000">
    		</div>
    	</header>

		<div id="header">
		
			<ul class="nav">
				<li><a href="">Pagina Principal</a></li>
				
				<li><a href="">Sistema de Pregrado</a>
					<ul>
						<li><a href="">Estudiantes</a></li>
						<li><a href="">Profesores</a>
							<ul>
								
								<li><a href="">Profesor</a></li>
								<li><a href="">Instructor de Laboratorio</a></li>
						
				
							</ul>
						
						
						</li>
						
				
					</ul>
				</li>
				
				
				<li><a href="">Sistema de Postgrado</a>
					
					<ul>
						<li><a href="">Estudiantes</a></li>
						<li><a href="">Profesores</a></li>
						
				
					</ul>
					
				</li>
			
			
			</ul>

			<a href="Prema.php">Atras</a><br/><a href="menu.php">Cerrar Sesion</a><br/>
			
			
			<div class="container">
            <h5>asignaturas</h5>
			<?php
				for($i = 0; $i < $filas; $i++){
					$id_asignatura=pg_fetch_result($consulta, $i, 'id_asignatura');
					echo $id_asignatura;
			?>
			<a href="listadosec.php?id_asignatura=<?php echo $id_asignatura;?>"><?php echo pg_fetch_result($consulta, $i, 'nombre_clase') ; ?></a><br>
			<?php				
				}	
			?>			
             
            </div>
            
    	
		
		</div>


	</body>
	
</html>	