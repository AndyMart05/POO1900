<?php
  ini_set('display_errors',1);
  ini_set('display_startup_errors',1);
  error_reporting(E_ALL);

  include ('../conexion.php');  
  $conex = new Conexion();
	$conexion = $conex->conect();
	$usuario = $_POST['usuario'];
	$contrasenia = $_POST['contrasenia'];
	$sql='SELECT id_usuario, id_tipo_usuario, nombre_usuario, contrasenia, foto
			FROM matricula.tbl_usuarios where nombre_usuario= $1 and contrasenia=$2 ';
			  
	$consulta = pg_query_params($conexion, $sql, array($usuario, $contrasenia));
	$filas = pg_num_rows($consulta);
	$datos=pg_fetch_array($consulta);
	$conex->cerrarConexion($conexion); 
	// echo $datos[0];
	// var_dump($datos);
	if ($filas == 0){
		header('Location: ../index.php');
		exit;
	}
	if ($filas >1)
	{
		echo 'usuairo duplicado en DB';
		exit;	
	}
?>
<html>
	<head>
		<title>Menu Principal </title>
		<style type="text/css">
		
			*  { 
			padding:0px;
			margin:0px;
			
			}
			
			#header{
				margin:auto;
				width:1000px;
				font-family:Arial,Helvetica,sans-serif;
			}
			
			ul, ol{
				list-style:none;
			}
			
			.nav li a{
				background-color:#262B78;
				color:#fff;
				text-decoration:none;
				padding:10px 15px;
				display:block;
			}
			
			.nav li a:hover {
				background-color:#5e8691;
			}
			.nav > li {
				float:left;
			}
			.nav li ul {
				display:none;
				position:absolute;
				min-width:140px;
			}
			
			.nav li:hover > ul {
				display:block;
			}
			
			.nav li ul li {
				position:relative;
			}
			.nav li ul li ul {
				right: -205px;
				top:0px;
				
			}
		</style>
	</head>

    <body>
    	<header>
    		<div>
    			<img src="superior.jpg" width="1000">
    		</div>
    	</header>

		<div id="header">
		
			<ul class="nav">
				<li><a href="">Pagina Principal</a></li>
				
				<li><a href="">Sistema de Pregrado</a>
					<ul>
						<li><a href="">Estudiantes</a></li>
						<li><a href="">Profesores</a>
							<ul>
								
								<li><a href="">Profesor</a></li>
								<li><a href="">Instructor de Laboratorio</a></li>
						
				
							</ul>
						
						
						</li>
						
				
					</ul>
				</li>
				
				
				<li><a href="">Sistema de Postgrado</a>
					
					<ul>
						<li><a href="">Estudiantes</a></li>
						<li><a href="">Profesores</a></li>
						
				
					</ul>
					
				</li>
			
			
			</ul>
         <ul>
			<li><?php echo $usuario;?></li>
		 </ul>
			<a href="login.php">Cerrar Sesion</a><br/>
			<br/>
			<br/>
            <ul>
            	<li><a href="">Historial Academico</a></li>
            	<li><a href="prema.php">Prematricula</a></li>
            	<li><a href="">abc</a></li>
            </ul>
    	
		
		</div>


	</body>
	
</html>	