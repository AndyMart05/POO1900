<?php 

ini_set('display_startup_errors',1);
  error_reporting(E_ALL);

  include ('../conexion.php');  
  $conex = new Conexion();
	$conexion = $conex->conect();
	// $usuario = $_POST['usuario'];
	// $contrasenia = $_POST['contrasenia'];
	$id_asignatura= $_GET['id_asignatura'];
	$sql='SELECT id_seccion, id_aula, id_docente, id_asignatura, limite_cupos, 
			codigo_seccion
		FROM matricula.tbl_secciones where id_asignatura= $1';
			  
	$consulta = pg_query_params($conexion, $sql, array($id_asignatura));
	$filas = pg_num_rows($consulta);
	$datos=pg_fetch_array($consulta);
	$conex->cerrarConexion($conexion);

// var_dump($datos);

?>




<html>
	<head>
		<title>Adicionar Asignatura</title>
		<style type="text/css">
		
			*  { 
			padding:0px;
			margin:0px;
			
			}
			
			#header{
				margin:auto;
				width:1000px;
				font-family:Arial,Helvetica,sans-serif;
			}
			
			ul, ol{
				list-style:none;
			}
			
			.nav li a{
				background-color:#262B78;
				color:#fff;
				text-decoration:none;
				padding:10px 15px;
				display:block;
			}
			
			.nav li a:hover {
				background-color:#5e8691;
			}
			.nav > li {
				float:left;
			}
			.nav li ul {
				display:none;
				position:absolute;
				min-width:140px;
			}
			
			.nav li:hover > ul {
				display:block;
			}
			
			.nav li ul li {
				position:relative;
			}
			
			.nav li ul li ul {
				right: -205px;
				top:0px;
				
			}
		</style>
	</head>

    <body>
    	<header>
    		<div>
    			<img src="superior.jpg" width="1000">
    		</div>
    	</header>

		<div id="header">
		
			<ul class="nav">
				<li><a href="">Pagina Principal</a></li>
				
				<li><a href="">Sistema de Pregrado</a>
					<ul>
						<li><a href="">Estudiantes</a></li>
						<li><a href="">Profesores</a>
							<ul>
								
								<li><a href="">Profesor</a></li>
								<li><a href="">Instructor de Laboratorio</a></li>
						
				
							</ul>
						
						
						</li>
						
				
					</ul>
				</li>
				
				
				<li><a href="">Sistema de Postgrado</a>
					
					<ul>
						<li><a href="">Estudiantes</a></li>
						<li><a href="">Profesores</a></li>
						
				
					</ul>
					
				</li>
			
			
			</ul>

			<a href="Prema.php">Atras</a><br/><a href="menu.php">Cerrar Sesion</a><br/>
			
			
			<div class="container">
            <h5>secciones</h5>
			<form action="forma03.php" method="post">
			<?php
				for($i = 0; $i < $filas; $i++){
					$id_seccion=pg_fetch_result($consulta, $i, 'id_seccion');
					echo $id_seccion;
			?>
			<select name="seccion" id="">
			<option value="<?php echo pg_fetch_result($consulta, $i, 'codigo_seccion');?>"><?php echo pg_fetch_result($consulta, $i, 'codigo_seccion') ; ?></option>
			</select>
			<!-- <input type="" name='' value=" "/> -->
			<br>
			<?php				
				}	
			?>	
			<input type="submit" name="matricular" id="" value="matricular">
			</form>
			
            </div>
			
    	
		
		</div>


	</body>
	
</html>	