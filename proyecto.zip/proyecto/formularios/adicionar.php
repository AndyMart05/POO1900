<?php
  ini_set('display_errors',1);
  ini_set('display_startup_errors',1);
  error_reporting(E_ALL);

  include ('../conexion.php');  
  $conex = new Conexion();
	$conexion = $conex->conect();
	// $usuario = $_POST['usuario'];
	// $contrasenia = $_POST['contrasenia'];
	$sql='SELECT id_carrera, id_facultad, cantidad_uv, cantidad_asignaturas, id_coordinador, 
					codigo_carrera, nombre_carrera
				FROM matricula.tbl_carreras ';
			  
	$consulta = pg_query_params($conexion, $sql, array());
	$filas = pg_num_rows($consulta);
	$datos=pg_fetch_array($consulta);
	$conex->cerrarConexion($conexion); 

	$id_carrera = $datos[0];
	$id_facultad = $datos[1];
	$cantidad_uv = $datos[2];
	$cantidad_asigaturas = $datos[3];//NOMBRE
    $id_coordinador = $datos[4];//APELLIDO
    $codigo_carrera = $datos[5];//NUMERO_CUENTA
    $nombre_carrera = $datos[6];
	
?>
<html>
	<head>
		<title>Adicionar Asignatura</title>
		<style type="text/css">
		
			*  { 
			padding:0px;
			margin:0px;
			
			}
			
			#header{
				margin:auto;
				width:1000px;
				font-family:Arial,Helvetica,sans-serif;
			}
			
			ul, ol{
				list-style:none;
			}
			
			.nav li a{
				background-color:#262B78;
				color:#fff;
				text-decoration:none;
				padding:10px 15px;
				display:block;
			}
			
			.nav li a:hover {
				background-color:#5e8691;
			}
			.nav > li {
				float:left;
			}
			.nav li ul {
				display:none;
				position:absolute;
				min-width:140px;
			}
			
			.nav li:hover > ul {
				display:block;
			}
			
			.nav li ul li {
				position:relative;
			}
			
			.nav li ul li ul {
				right: -205px;
				top:0px;
				
			}
		</style>
	</head>

    <body>
    	<header>
    		<div>
    			<img src="superior.jpg" width="1000">
    		</div>
    	</header>

		<div id="header">
		
			<ul class="nav">
				<li><a href="">Pagina Principal</a></li>
				
				<li><a href="">Sistema de Pregrado</a>
					<ul>
						<li><a href="">Estudiantes</a></li>
						<li><a href="">Profesores</a>
							<ul>
								
								<li><a href="">Profesor</a></li>
								<li><a href="">Instructor de Laboratorio</a></li>
						
				
							</ul>
						
						
						</li>
						
				
					</ul>
				</li>
				
				
				<li><a href="">Sistema de Postgrado</a>
					
					<ul>
						<li><a href="">Estudiantes</a></li>
						<li><a href="">Profesores</a></li>
						
				
					</ul>
					
				</li>
			
			
			</ul>

			<a href="Prema.php">Atras</a><br/><a href="menu.php">Cerrar Sesion</a><br/>
			
			
			<div class="container">
            <h5>Carrera</h5>
            <div class="collection">
		

			<?php
				for($i = 0; $i < $filas; $i++){
					$id_carrera=pg_fetch_result($consulta, $i, 'id_carrera');
			?>
			<a href="listadoasig.php?id_carrera=<?php echo $id_carrera;?>"><?php echo pg_fetch_result($consulta, $i, 'nombre_carrera');?></a><br>
							
			<?php				
				}	
			?>			
             
            </div>
            </div>
            
    	
		
		</div>


	</body>
	
</html>	