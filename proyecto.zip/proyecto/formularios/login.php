<html>
	<head>
		<title>Sistema de prematricula/LogIn </title>
		<style type="text/css">
		
			*  { 
			padding:0px;
			margin:0px;
			
			}
			label{
				display: block;
				width: 25%;
			}

			
			#header{
				margin:auto;
				width:1000px;
				font-family:Arial,Helvetica,sans-serif;
			}
			
			ul, ol{
				list-style:none;
			}
			
			.nav li a{
				background-color:#262B78;
				color:#fff;
				text-decoration:none;
				padding:10px 15px;
				display:block;
			}
			
			.nav li a:hover {
				background-color:#5e8691;
			}
			.nav > li {
				float:left;
			}
			.nav li ul {
				display:none;
				position:absolute;
				min-width:140px;
			}
			
			.nav li:hover > ul {
				display:block;
			}
			
			.nav li ul li {
				position:relative;
			}
			
			.nav li ul li ul {
				right: -205px;
				top:0px;
				
			}
		</style>
	</head>

    <body>
    	<header>
    		<div>
    			<img src="superior.jpg" width="1000">
    		</div>
    	</header>

		<div id="header">
		
			<ul class="nav">
				<li><a href="">Pagina Principal</a></li>
				
				<li><a href="">Sistema de Pregrado</a>
					<ul>
						<li><a href="">Estudiantes</a></li>
						<li><a href="">Profesores</a>
							<ul>
					
								<li><a href="">Profesor</a></li>
								<li><a href="">Instructor de Laboratorio</a></li>
						
				
							</ul>
						
						
						</li>
						
				
					</ul>
				</li>
				
				
				<li><a href="">Sistema de Postgrado</a>
					
					<ul>
						<li><a href="">Estudiantes</a></li>
						<li><a href="">Profesores</a></li>
						
				
					</ul>
					
				</li>
			
			
			</ul>

			<a href="menu.php">Cerrar Sesion</a><br/>
			<br/>
			<br/>
            <?php
				if(isset(s_GET['error'])){
				echo '<p>Credenciales erroneas,Favor revise.</p>';
				}
				?>
    	<form action= "../formularios/menuprincipal.php" method="post">
    		<fieldset>
    			<legend>Ingreso</legend>
    			<label for "usuario">Usuario</label>
    			<input type="text" name="usuario" required value="20121004463">
    			<br>
    			<label for= "clave">Clave</label>
    			<input type="password" name="contrasenia" id="clave"required value="12345">
    			<input type= "submit" value="Inciar Sesion">
    		</fieldset>
    	</form>	
		
		</div>


	</body>
	
</html>	