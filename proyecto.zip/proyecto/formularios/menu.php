<html>
	<head>
		<title>Sistema de prematricula </title>
		<style type="text/css">
		
			*{ 
			padding:0px;
			margin:0px;
			
			}
			
			#header{
				margin:auto;
				width:1000px;
				font-family:Arial,Helvetica,sans-serif;
			}
			
			ul, ol{
				list-style:none;
			}
			
			.nav li a{
				background-color:#000;
				color:#fff;
				text-decoration:none;
				padding:10px 15px;
				display:block;
			}
			
			.nav li a:hover; {
				background-color:#434343;
			}
			.nav >li {
				float:left;
			}
			.nav li ul{
				display:none;
				position:absolute;
				min-width:140px;
			}
			
			.nav li:hover > ul {
				display:block;
			}
			
			.nav li ul li {
				position:relative;
			}
			
			.nav lil ul li il {
				right: -140px;
				top:0px;
				
			}
		</style>
	<head>

    <body>

		<div id="header">
		
			<ul class="nav">
				<li><a href="">Pagina Principal</a></li>
				
				<li><a href="">Sistema de Pregrado</a>
					<ul>
						<li><a href="Login.php">23122Estudiantes</a></li>
						<li><a href="">Profesores</a>
							<ul>
								
								<li><a href="">Profesor</a></li>
								<li><a href="">Instructor de Laboratorio</a></li>
						
				
							</ul>
						
						
						</li>
						
				
					</ul>
				</li>
				
				
				<li><a href="">Sistema de Postgrado</a>
					
					<ul>
						<li><a href="">Estudiantes</a></li>
						<li><a href="">Profesores</a></li>
						
				
					</ul>
					
				</li>
			
			
			</ul>
				
		
		</div>


	</body>
	
</html>	