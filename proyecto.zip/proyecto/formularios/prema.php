<html>
	<head>
		<title>prematricula</title>
		<style type="text/css">
		
			*  { 
			padding:0px;
			margin:0px;
			
			}
			
			#header{
				margin:auto;
				width:1000px;
				font-family:Arial,Helvetica,sans-serif;
			}
			
			ul, ol{
				list-style:none;
			}
			
			.nav li a{
				background-color:#262B78;
				color:#fff;
				text-decoration:none;
				padding:10px 15px;
				display:block;
			}
			
			.nav li a:hover {
				background-color:#5e8691;
			}
			.nav > li {
				float:left;
			}
			.nav li ul {
				display:none;
				position:absolute;
				min-width:140px;
			}
			
			.nav li:hover > ul {
				display:block;
			}
			
			.nav li ul li {
				position:relative;
			}
			
			.nav li ul li ul {
				right: -205px;
				top:0px;
				
			}
		</style>
	</head>

    <body>
    	<header>
    		<div>
    			<img src="superior.jpg" width="1000">
    		</div>
    	</header>

		<div id="header">
		
			<ul class="nav">
				<li><a href="">pagina Principal</a></li>
				
				<li><a href="">sistema de Pregrado</a>
					<ul>
						<li><a href="">Estudiantes</a></li>
						<li><a href="">Profesores</a>
							<ul>
								
								<li><a href="">Profesor</a></li>
								<li><a href="">Instructor de Laboratorio</a></li>
						
				
							</ul>
						
						
						</li>
						
				
					</ul>
				</li>
				
				
				<li><a href="">Sistema de Postgrado</a>
					
					<ul>
						<li><a href="">Estudiantes</a></li>
						<li><a href="">Profesores</a></li>
						
				
					</ul>
					
				</li>
			
			
			</ul>

			<a href="menuprincipal.php">Atras</a><br/><a href="menu.php">Cerrar Sesion</a><br/>
			<br/>
			<br/>
			<p>Matricula de Pregrado</p>
			<br/>
			<br/>
            <ul>
            	<li><a href="adicionar.php">Adicionar Asignatura</a></li>
            	<li><a href="Cancelar.php">Cancelar Asignatura</a></li>
            	<li><a href="Forma 03.php">Forma 03</a></li>
            </ul>
    	
		
		</div>


	</body>
	
</html>	