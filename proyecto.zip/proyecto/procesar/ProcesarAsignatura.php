<?php

include 'Asignatura,php';

// $Facultad = $_POST[];
// $Asignatura = $_POST[];
// $Seccion = $_POST[];