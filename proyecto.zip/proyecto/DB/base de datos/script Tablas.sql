﻿CREATE TABLE "matricula"."tbl_tipo_usuario"
(
  "id_tipo_usuario" numeric(3,0),
  "nombre_tipo" character varying(50),
  "descripcion" character varying(100)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE "matricula"."tbl_tipo_usuario"
  OWNER TO "matricula";
--///////////////////////////////////////////////
CREATE TABLE "matricula"."tbl_usuarios"
(
  "id_usuario" numeric(3,0),
  "id_tipo_usuario" numeric(3,0),
  "nombre_usuario" character varying(50),
  "contrasenia" character varying(50),
  "foto" character varying(500)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE "matricula"."tbl_usuarios"
  OWNER TO "matricula";

--///////////////////////////////////////////////
CREATE TABLE "matricula"."tbl_secciones"
(
  "id_seccion" numeric(3,0),
  "id_aula" numeric(3,0),
  "id_docente" numeric(3,0),
  "id_asignatura" numeric(3,0),
  "limite_cupos" numeric(3,0),
  "codigo_seccion" character varying(50)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE "matricula"."tbl_secciones"
  OWNER TO "matricula";
--///////////////////////////////////////////////
CREATE TABLE "matricula"."tbl_matricula"
(
  "id_matricula" numeric(3,3),
  "id_seccion" numeric(3,3),
  "id_carrera" numeric(3,3),
  "id_alumno" numeric(3,3),
  "id_asignatura" numeric(3,3),
  "id_estado" numeric(3,3),
  "fecha_matricula" character varying(50)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE "matricula"."tbl_matricula"
  OWNER TO "matricula";
--///////////////////////////////////////////////
CREATE TABLE "matricula"."tbl_lista_espera"
(
  "id_lista_espera" numeric(3,3),
  "id_seccion" numeric(3,3),
  "id_alumno" numeric(3,3),
  "id_aula" numeric(3,3),
  "id_asignatura" numeric(3,3)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE "matricula"."tbl_lista_espera"
  OWNER TO "matricula";
--///////////////////////////////////////////////
CREATE TABLE "matricula"."tbl_carreras"
(
  "id_carrera" numeric(3,0),
  "id_facultad" numeric(3,0),
  "cantidad_uv" numeric(3,0),
  "cantidad_asignaturas" numeric(3,0),
  "id_coordinador" numeric(3,0),
  "codigo_carrera" character varying(50),
  "nombre_carrera" character varying(50)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE "matricula"."tbl_carreras"
  OWNER TO "matricula";

--///////////////////////////////////////////////
  CREATE TABLE "matricula"."tbl_asignaturas"
(
  "id_asignatura" numeric(3,0),
  "id_seccion" numeric(3,0),
  "id_docente" numeric(3,0),
  "id_aula" numeric(3,0),
  "ID_CARRERA" numeric(3,0),
  "codigo_clase" character varying(15),
  "nombre_clase" character varying(50),
  "dias_clase" character varying(50),
  "hora_inicio" character varying(50),
  "hora_fin" character varying(50),
  "cantida_uv" numeric(3,0)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE "matricula"."tbl_asignaturas"
  OWNER TO "matricula";
--///////////////////////////////////////////////
CREATE TABLE "matricula"."tbl_alumnos"
(
  "id_alumno" numeric(3,0),
  "id_carrera" numeric(3,0),
  "id_facultad" numeric(3,0),
  "nombre" character varying(50),
  "apellido" character varying(50),
  "numero_cuenta" character varying(50),
  "indice_academico_global" numeric(3,0),
  "incice_academco_periodo" numeric(3,0),
  "id_usuario" numeric(3,0)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE "matricula"."tbl_alumnos"
  OWNER TO "matricula";